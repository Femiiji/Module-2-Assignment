# Path to the zipped folder(change path here if path is different)
zip_path <- "/Users/user/Desktop/Employee folder/Employee folder.zip"

# Directory to extract the folder contents
extract_dir <- "employee_folder_unzipped"

# Create directory if it doesn't already exist
if (!dir.exists(extract_dir)) {
  dir.create(extract_dir)
}

# UNZIP THE FOLDER ZIP
unzip(zip_path, exdir = extract_dir)

# After unzipping, list all CSV files inside the extracted folder
csv_files <- list.files(extract_dir, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)

# Error handling if no CSV found
if (length(csv_files) == 0) {
  stop("No CSV file found inside the unzipped folder.")
}

# Read the first CSV file
employee_df <- read.csv(csv_files[1])

# Display data
print(employee_df)
